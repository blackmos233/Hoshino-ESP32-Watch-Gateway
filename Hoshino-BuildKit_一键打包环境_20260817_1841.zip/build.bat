@echo off
chcp 65001 >nul
cd /d %~dp0
setlocal

echo ============================================
echo   Hoshino ESP32 Watch Gateway - One-click Build
echo   Put your firmware source in "main\main.cpp"
echo ============================================
echo.

if not exist "main\main.cpp" (
    echo [ERROR] main\main.cpp not found.
    echo Put your firmware source file into the "main" folder.
    pause
    exit /b 1
)

set "PIO_CMD="
where pio >nul 2>nul
if not errorlevel 1 (
    set "PIO_CMD=pio"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo [ERROR] PlatformIO not found.
        echo Install:  pip install platformio
        pause
        exit /b 1
    )
    python -c "import platformio" >nul 2>nul
    if errorlevel 1 (
        echo [ERROR] PlatformIO not found.
        echo Install:  pip install platformio
        pause
        exit /b 1
    )
    set "PIO_CMD=python -m platformio"
)

echo [1/4] Compiling (wroom_lowmem_idf) ...
call %PIO_CMD% run -e wroom_lowmem_idf
if errorlevel 1 (
    echo [ERROR] Build failed. Check your source code.
    pause
    exit /b 1
)

echo [2/4] Collecting firmware ...
if not exist "output" mkdir "output"
copy /y ".pio\build\wroom_lowmem_idf\firmware.bin"   "output\" >nul
copy /y ".pio\build\wroom_lowmem_idf\bootloader.bin"  "output\" >nul
copy /y ".pio\build\wroom_lowmem_idf\partitions.bin"  "output\" >nul
copy /y "main\main.cpp" "output\main.cpp" >nul

echo [3/4] Zipping ...
powershell -NoProfile -Command "$o='%~dp0output'; $z=Join-Path $o 'Hoshino_Firmware.zip'; if(Test-Path $z){Remove-Item $z -Force}; Compress-Archive -Path (Join-Path $o '*') -DestinationPath $z -Force"
if errorlevel 1 (
    echo [ERROR] Zip failed.
    pause
    exit /b 1
)

echo [4/4] Copying to Desktop ...
powershell -NoProfile -Command "$dt=[Environment]::GetFolderPath('Desktop'); $z=Join-Path '%~dp0output' 'Hoshino_Firmware.zip'; $dst=Join-Path $dt ('Hoshino_Firmware_' + (Get-Date -Format 'yyyyMMdd_HHmm') + '.zip'); Copy-Item $z $dst -Force; Write-Host 'Saved: ' $dst"

echo.
echo Done! Firmware package saved to Desktop.
pause
